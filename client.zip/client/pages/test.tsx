import Link from "next/link";
export default () => {
  return (
    <>
      <h1>test yaya</h1>
      <Link href="/">Test</Link>
    </>
  );
};
